#/usr/bin/env python
# -*- coding: utf-8 -*-

__all__ = ['DIP', 'ISP', 'LSP', 'open_close', 'single_responsibility']